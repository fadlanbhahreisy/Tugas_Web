<?= $this->extend('layout'); ?>
<?= $this->section('content'); ?>

<?= $this->endSection(); ?>